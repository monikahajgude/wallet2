package application.exceptionHandling;

public class InvalidNameException extends Exception{
	private static final long serialVersionUID = 1L;
	public InvalidNameException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	public String getMessage(){
		String msg = super.getMessage();
			return msg;
	}
	
}