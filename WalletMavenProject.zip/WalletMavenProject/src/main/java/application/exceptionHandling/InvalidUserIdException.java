package application.exceptionHandling;

public class InvalidUserIdException extends Exception{
	private String uuid; 
	
	public InvalidUserIdException(String msg,String uuid) {
		super(msg);
		this.uuid = uuid;
	}
	public String getMessage() {
		String msg = super.getMessage();
		return msg+" You have entered this user id - "+uuid;
	}
	
}
