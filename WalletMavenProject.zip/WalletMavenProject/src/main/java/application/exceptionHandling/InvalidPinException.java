package application.exceptionHandling;

public class InvalidPinException extends Exception{
	private String pin ;
	public InvalidPinException(String msg, String pin) {
		super(msg);
		this.pin = pin;
		
	}
	public String getMessage(){
		String msg = super.getMessage();
			return msg+"You have enterdred this pin :"+pin;
	}
	
}
