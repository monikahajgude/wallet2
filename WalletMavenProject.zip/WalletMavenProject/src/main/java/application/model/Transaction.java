package application.model;




import java.util.Date;

import javax.persistence.Embeddable;




@Embeddable
public class Transaction{
	/**
	 * 
	 */
	
	
	
	private int transactionId;
	private double amount;		
	private  Date timeStamp;
	private String description;
	
		
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
		@Override
	public String toString() {
		return amount+"		 "+ description+"    "+timeStamp.toString();
	}
	public 	Transaction(){
		this.amount = 00;
		
		this.timeStamp =null;
		this.description = "";
	}
		
	
	public Transaction(int transactionId, double amount, Date timeStamp, String description) {
		super();
		this.transactionId = transactionId;
		this.amount = amount;
		this.timeStamp = timeStamp;
		this.description = description;
	}
	 
		public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
		public Transaction(double amount,Account transAccount) {
			this.amount = amount;
			
			this.timeStamp = new Date();
			this.description = "";
			
		}
		
		
		public Date getTimeStamp() {
			return timeStamp;
		}
		public void setTimeStamp(Date timeStamp) {
			this.timeStamp = timeStamp;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		
		
}
