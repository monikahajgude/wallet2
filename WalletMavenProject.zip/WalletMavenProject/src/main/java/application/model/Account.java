package application.model;




import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="account_database")
public class Account {
		/**
	 * 
	 */
	private static final long serialVersionUID = 7875737790231507160L;
	
		@Id
		private String accountNo;
		private double balance;
		@OneToOne(cascade = CascadeType.ALL)		
		private Customer user;
		@ElementCollection
		private List<Transaction> transactions;
		public Account() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Account(String accountNo, double balance, Customer user, ArrayList<Transaction> transactions) {
			super();
			this.accountNo = accountNo;
			this.balance = balance;
			this.user = user;
			this.transactions = transactions;
		}
		public String getAccountNo() {
			return accountNo;
		}
		public void setAccountNo(String accountNo) {
			this.accountNo = accountNo;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
		public Customer getUser() {
			return user;
		}
		public void setUser(Customer user) {
			this.user = user;
		}
		public List<Transaction> getTransactions() {
			return transactions;
		}
		public void setTransactions(List<Transaction> transactions) {
			this.transactions = transactions;
		}
		public static long getSerialversionuid() {
			return serialVersionUID;
		}
		
}

