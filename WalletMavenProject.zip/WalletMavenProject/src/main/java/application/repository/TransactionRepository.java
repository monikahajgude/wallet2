/*
 * package application.repository;
 * 
 * import org.springframework.data.jpa.repository.JpaRepository;
 * 
 * import application.model.Transaction;
 * 
 * public interface TransactionRepository<Int> extends
 * JpaRepository<Transaction,Int>{
 * 
 * }
 */