package application.test;



import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import application.model.AccountTransaction;
import application.model.AccountUser;
import application.repository.AccountTransactionRepository;
import application.repository.AccountUserRepository;
import application.service.AccountService;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;


@Transactional
@RunWith(SpringRunner.class)
@ExtendWith(SpringExtension.class)
@SpringBootTest
public class TestAccountService extends AbstractTest {
	
	private static Logger logger=LogManager.getRootLogger();
	
	
	@Autowired
	private AccountService testService;

	@Autowired
	private AccountUserRepository userRepo;

	@Autowired
	private AccountTransactionRepository transactionRepo;
	@BeforeAll
	static void setUpBeforeClass() {
		logger = LogManager.getRootLogger();
		System.out.println("Fetching resources for testing ...");
	}


	@Test
	public void testCreateAccountSuccess(){
		logger.info("Test case -Create account successfully.");
		AccountUser user = new AccountUser("B1234556", 0, "Mahima", "Khanna", "1234");
		userRepo.delete(user);
		String resultstring = testService.createAccount(user);
		String expected ="Account Created Successfully";
		assertEquals(expected, resultstring);
	}
	
	
	@Test
	public void testCreateAccountUnsuccess() throws Exception {
		logger.info("Test case -Create account unsuccessful as account number already exist.");
		AccountUser user = new AccountUser("A1234545", 0, "Mahima", "Khanna", "1234");
		userRepo.save(user);
		AccountUser user1 = new AccountUser("A1234545", 0, "Rash", "krishna", "1255");
		String resultstring = testService.createAccount(user1);
		String expected ="Account Number Already exists. Please try another account number or login !!";
		assertEquals(expected, resultstring);
	}


	@Test
	public void testGetAllAccount() {
		logger.info("Test case -get all transactions");
		List<AccountUser> listResult = testService.getAllAccount();
		assertNotNull(listResult);
	}

	@Test
	public void testUpdateAccountSuccess() {
		logger.info("Test case -Update account details successfully");
		AccountUser user = new AccountUser("A12345", 1000, "Mahima", "Khanna", "1234");
		userRepo.save(user);
		AccountUser updateUser = new AccountUser("A12345", 0, "Mahima", "Khanna", "1254");
		AccountUser result = testService.updateAccount(updateUser);
		assertEquals(user.getAccountNo(), result.getAccountNo());
		assertTrue(result.getBalance() == 1000);

	}
	
	@Test
	public void testUpdateAccountUnsuccess() {
		logger.info("Test case -Upadate account unsuccessful as user does not exist.");
		AccountUser updateUser = new AccountUser("A1234567", 0, "Mahima", "Khanna", "1254");
		AccountUser result = testService.updateAccount(updateUser);
		assertEquals(null,result);
		

	}

	@Test
	public void testWithdrawSuccess() {
		logger.info("Test case -Withdraw money successfully");
		AccountUser user = new AccountUser("A1234568",(Double) 1000.0, "Mahima", "Khanna", "1234");
		userRepo.save(user);
		String resultString = testService.withdraw((Double)100.0, user);
		String expected = "Money withdraw successfully!!";
		assertEquals(expected, resultString);

	}
	
	//Account Does not exist
	@Test
	public void testWithdrawUnsuccess1() {
		logger.info("Test case -Withdraw unsuccess  as account does not exists");
		AccountUser user = new AccountUser("A1234515", 1000, "Mahima", "Khanna", "1234");
		//userRepo.delete(user);
		String resultString = testService.withdraw((double) 100, user);
		String expected = "Account does not exist";
		assertEquals(expected, resultString);

	}
	
	@Test
	public void testWithdrawUnsuccess2() {
		logger.info("Test case -Withdraw unsuccess because balance is insufficient.");
		AccountUser user = new AccountUser("A12345", 1000, "Mahima", "Khanna", "1234");
		userRepo.save(user);
		String resultString = testService.withdraw((double) 10002, user);
		String expected = "Low balance";
		assertEquals(expected, resultString);

	}
	@Test
	public void testWithdrawUnsuccess3() {
		logger.info("Test case -Withdraw unsuccess because pin is incorrect.");
		AccountUser user = new AccountUser("A1234568",(Double) 1000.0, "Mahima", "Khanna", "1234");
		userRepo.save(user);
		AccountUser user2 = new AccountUser("A1234568",(Double) 1000.0, "Mahima", "Khanna", "1223");
		String resultString = testService.withdraw((Double)100.0, user2);
		String expected = "Incorrect pin";
		assertEquals(expected, resultString);

	}
@Test
public void testDepositSuccess() {
	logger.info("Test case -Amount deposited successfully");
		AccountUser user = new AccountUser("A12345", 1000, "Mahima", "Khanna", "1234");
		userRepo.save(user);
		String resultString = testService.deposit(100, user);
		String expected = "Amount deposited successfully";
		assertEquals(expected, resultString);
	}
	
	@Test
	public void testDepositUnsuccess() {
		logger.info("Test case -Deposit unsuccessful as account does not exists");
		AccountUser user = new AccountUser("A123453", 1000, "Mahima", "Khanna", "1234");
		
		String resultString = testService.deposit(100, user);
		String expected ="Account does not exist";
		assertEquals(expected, resultString);
	}

	
	@Test
	public void testGetAccountByIdSuccess() {
		logger.info("Test case -Get by id successful. ");
		AccountUser user = new AccountUser("A12345", 1000, "Mahima", "Khanna", "1234");
		userRepo.save(user);
		Object result = testService.getAccountById(user.getAccountNo());
		assertEquals(user, result);

	}
	
	@Test
	public void testGetAccountByIdUnsuccess() {
		logger.info("Test case -Get by id unsuccessful as account does not exists");
		AccountUser user = new AccountUser("A123455514", 1000, "Mahima", "Khanna", "1234");
		Object result = testService.getAccountById(user.getAccountNo());
		assertEquals(null, result);

	}

	@Test
	public void testLoginSuccess() {
		logger.info("Test case -Login successful ");
		AccountUser user = new AccountUser("A12345", 1000, "Mahima", "Khanna", "1234");
		userRepo.save(user);
		String resultString = testService.Login(user);
		String expected = "Login successfull !!";
		assertEquals(expected, resultString);
	}
	
	@Test
	public void testLoginUnsuccess1() {
		logger.info("Test case -Login unsuccessful as  account number is invalid");
		AccountUser user1 = new AccountUser("A12345", 1000, "Mahima", "Khanna", "1234");
		userRepo.save(user1);
		AccountUser user = new AccountUser("A1234545", 1000, "Mahima", "Khanna", "1234");
		String resultString = testService.Login(user);
		String expected = "Account Number is invalid !!";
		assertEquals(expected, resultString);
	}
	
	@Test
	public void testLoginUnsuccess2() {
		logger.info("Test case -Login unsuccessful as pin does not match. ");
		AccountUser user1 = new AccountUser("A12345", 1000, "Mahima", "Khanna", "1234");
		userRepo.save(user1);
		AccountUser user = new AccountUser("A12345", 1000, "Mahima", "Khanna", "123");
		String resultString = testService.Login(user);
		String expected = "Pin does not match";
		assertEquals(expected, resultString);
	}
	
	@Test
	public void testGetBalanceSuceess() {
		logger.info("Test case -Get balance success");
		AccountUser user = new AccountUser("A12345", 1000, "Mahima", "Khanna", "1234");
		userRepo.save(user);
		String resultString = testService.getBalance(user.getAccountNo());
		String expected = "balance is 1000.0";
		assertEquals(expected, resultString);
	}
	
	@Test
	public void testGetBalanceUnsuceess() {
		logger.info("Test case -Get balance unsuccessful as account does not exists");
		AccountUser user = new AccountUser("A12345456", 1000, "Mahima", "Khanna", "1234");
		String resultString = testService.getBalance(user.getAccountNo());
		String expected = "Account Does Not Exists";
		assertEquals(expected, resultString);
	}

	
	@Test
	public void testPrintTransactionSuccess() {
		logger.info("Test case -Print transaction success");
		AccountUser user = new AccountUser("A123453", 1000, "Mahima", "Khanna", "1234");
		userRepo.save(user);
		Date time = new Date();
		AccountTransaction Transaction = new AccountTransaction("A123453" + "" + time, "A123453", 100, time,
				" transaction ");
		transactionRepo.save(Transaction);
		List<AccountTransaction> resulttransaction = testService.printTransaction("A123453");
		assertTrue(resulttransaction!=null);
	}

	@Test
	public void testPrintTransactionUnsuccess() {
		logger.info("Test case -Print transaction unsuccessful as the account of which transactions is to be print does not exists.");
		List<AccountTransaction> resulttransaction = testService.printTransaction("12255555");
		assertEquals(null, resulttransaction);
	}

	@Test
	public void testFundTransferSuccess() {
		logger.info("Test case -Fund transfered successful");
		AccountUser user1 = new AccountUser("A12345", 1000, "Mahima", "Khanna", "1234");
		userRepo.save(user1);
		AccountUser user2 = new AccountUser("A23456", 1000, "Mahi", "Khan", "1234");
		userRepo.save(user2);
		String resultString = testService.fundTransfer(200, user2.getAccountNo(), user1);
		String expected = "Fund transfered successfully !!";
		assertEquals(expected, resultString);
	}
	
	@Test
	public void testFundTransferUnSuccess1() {
		logger.info("Test case -Fund transfer unsuccessful as account by whome money is to be transfered does not exists.");
		AccountUser user1 = new AccountUser("A12345333", 1000, "Mahima", "Khanna", "1234");
		AccountUser user2 = new AccountUser("A23456", 1000, "Mahi", "Khan", "1234");
		userRepo.save(user2);
		String resultString = testService.fundTransfer(200,"A23456" , user1);
		String expected = "Account does not exist";
		assertEquals(expected, resultString);
	}
	
	@Test
	public void testFundTransferUnSuccess2() {
		logger.info("Test case -Fund transfer unsuccessful as account to whome money is to be transfered does not exists.");
		AccountUser user1 = new AccountUser("A12345333", 1000, "Mahima", "Khanna", "1234");
		AccountUser user2 = new AccountUser("A23456", 1000, "Mahi", "Khan", "1234");
		userRepo.save(user1);
		String resultString = testService.fundTransfer(200,"A23456" , user1);
		String expected = "Account does not exist";
		assertEquals(expected, resultString);
	}
	
	@Test
	public void testFundTransferUnSuccess3() {
		logger.info("Test case -Fund transfer unsuccessful as balance is less.");
		AccountUser user1 = new AccountUser("A12345", 100, "Mahima", "Khanna", "1234");
		userRepo.save(user1);
		AccountUser user2 = new AccountUser("A23456", 1000, "Mahi", "Khan", "1234");
		userRepo.save(user2);
		String resultString = testService.fundTransfer(200, user2.getAccountNo(), user1);
		String expected = "Low balance";
		assertEquals(expected, resultString);
	}

}
