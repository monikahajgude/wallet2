package application.test;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import application.controller.AccountController;
import application.exceptionHandling.ResourceNotFoundException;
import application.model.AccountTransaction;
import application.model.AccountUser;
import application.repository.AccountTransactionRepository;
import application.repository.AccountUserRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
public class TestAccount {

	@Autowired
	private AccountUserRepository userRepo;
	
	
	
	@Autowired
	private AccountTransactionRepository transactionRepo;
	
	
	
	@Test
	public void testCreateAccount() {
		AccountUser user = new AccountUser("A12345", 0, "Mahi", "Khanna", "1234");
		userRepo.save(user);
		Optional<AccountUser> optionaluser2 = userRepo.findById("A12345");
		AccountUser		user2 = optionaluser2.get();
			
	        assertEquals(user2.getFirstName(),user.getFirstName());
	        assertEquals(user2.getLastName(),user.getLastName());
		
	}
	
	 
	   @Test
		public void testUpdateAccount() {
			AccountUser user = new AccountUser("A12345", 1200, "Mahi", "Khanna", "1234");
			userRepo.save(user);
			AccountUser user2 = new AccountUser("A12345", 0, "Mahima", "Khanna", "2345");
			user2.setBalance(user.getBalance());
			userRepo.delete(user);
			userRepo.save(user2);
			Optional<AccountUser> opUpdatedUser = userRepo.findById(user.getAccountNo());
			AccountUser updatedUser = opUpdatedUser.get();
			assertNotNull(user2);
			assertEquals(user2.getFirstName(), updatedUser.getFirstName());
			assertEquals(user2.getLastName(), updatedUser.getLastName());
					}
	  
	  @Test public void testGetAccountById(){ AccountUser user = new
	  AccountUser("A12345", 0, "Mahi", "Khanna", "1234"); userRepo.save(user);
	  Optional<AccountUser> optionaluser2 = userRepo.findById("A12345");
	  AccountUser user2 = optionaluser2.get();
	  assertEquals(user2.getFirstName(),user.getFirstName());
	 assertEquals(user2.getLastName(),user.getLastName()); }
	  
	  
	 
	  @Test
	  public void testPrintTransaction() {
		  Date time = new Date();
			AccountTransaction Transaction = new AccountTransaction("A123453" + "" + time,
					"A123453", 100, time, " transaction " );
			transactionRepo.save(Transaction);
			List<AccountTransaction> resulttransaction = transactionRepo.findAll();
			
			assertNotNull(resulttransaction);
	  }
	  
}
