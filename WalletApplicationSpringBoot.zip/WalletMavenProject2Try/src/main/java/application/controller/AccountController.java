package application.controller;



import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import application.exceptionHandling.ResourceNotFoundException;
import application.model.AccountTransaction;
import application.model.AccountUser;
import application.model.ResultMessage;
import application.service.AccountServiceImpl;


/*Cotroller class for controlling the flow of function  */
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping({ "/wallet" })
public class AccountController {
		
	
	@Autowired
	AccountServiceImpl service;
	public AccountController() {
		service=new AccountServiceImpl();
	}
	
	@GetMapping("/getAccounts")
	public List<AccountUser> getAllAccount() {
		 
		return service.getAllAccount();	}
	
	
	
	@PostMapping("/createAccount")
	public ResponseEntity<ResultMessage> createAccount(@RequestBody AccountUser user) {
		ResultMessage result=new  ResultMessage();
		
		result.setMessage(service.createAccount(user));
	
		return ResponseEntity.ok().body(result);
	
	}
	
	
	
	
	    
	@PostMapping("/updateAccount")
	public AccountUser updateAccount(@RequestBody AccountUser user) throws ResourceNotFoundException{
		return service.updateAccount(user);
		
	}
	
	
	
	
	
	
	@PostMapping("/withdraw/{money}")
	public ResponseEntity<ResultMessage> withdraw(@PathVariable(value = "money") Double money,
			@RequestBody AccountUser user) {
		ResultMessage result=new  ResultMessage(); 
		
			// TODO: handle exception
			result.setMessage(service.withdraw(money, user));
		
			return ResponseEntity.ok(result);
		
		
		
	}
	
	
	
	
	@PostMapping("/deposit/{money}")
	public ResponseEntity<ResultMessage> deposit(@PathVariable(value = "money") float money, @RequestBody AccountUser user) {
		ResultMessage result=new  ResultMessage(); 
		
		
			result.setMessage(service.deposit(money, user));
		
			return ResponseEntity.ok(result);
		
	}

	@GetMapping("/getUser/{number}")
	public ResponseEntity<AccountUser> getAccountById(@PathVariable(value = "number") String number)
	{
		
			return ResponseEntity.ok().body(service.getAccountById(number));
		
	}
	
	
	
	@PostMapping("/doLogin")
	public ResponseEntity<ResultMessage> Login( @RequestBody AccountUser user1)
			 {
		ResultMessage result=new  ResultMessage();
		
			result.setMessage(service.Login(user1));
		
			return ResponseEntity.ok().body(result);
		
	}
	
	
	@GetMapping("/getaccountBalance/{number}")	
	public ResponseEntity<String> getBalance(@PathVariable(value = "number") String number)
			{
						return ResponseEntity.ok().body(service.getBalance(number));
			
		
	}
	
	
		@GetMapping("/printTransaction/{number}")
	public ResponseEntity<List<AccountTransaction>> printTransaction(@PathVariable(value = "number") String number)
			 {
		
				return ResponseEntity.ok().body(service.printTransaction(number));
	}
	
	
	
	@PostMapping("/fundtransfer/{amount}/{accountNumber1}")
	public ResponseEntity<ResultMessage> fundTransfer(@PathVariable(value = "amount") float amount,@PathVariable(value = "accountNumber1") String accountNumber,
			@RequestBody AccountUser user) {
		
		ResultMessage result = new ResultMessage();
					result.setMessage(service.fundTransfer(amount, accountNumber, user));
		
			return ResponseEntity.ok().body(result);
		
	}
}
