package application.Dao;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import application.exceptionHandling.UserAccountWithNumberNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

import application.exceptionHandling.InsufficientBalanceException;

import application.model.AccountTransaction;
import application.model.AccountUser;

import application.repository.AccountTransactionRepository;
import application.repository.AccountUserRepository;

/*Class for managing all the operation this is  class for implementing dao*/
@Repository
public class DaoImpl implements Dao{
	@Autowired
	private AccountUserRepository userRepo;
	@Autowired
	private AccountTransactionRepository transactionRepo;
	
	
//***********************************************Function for getting all the account details***************************************************************************************************
	public List<AccountUser> getAllAccount() {

		return userRepo.findAll();
	}
//****************************************************End of getAll function*****************************************************************************************
	

//****************************************************Function for creating account*****************************************************************************************
	
	public String createAccount(AccountUser user) {
		try {
		Optional<AccountUser> optionalAccountUser = userRepo.findById(user.getAccountNo());
		AccountUser accountUser = optionalAccountUser.get();
		if (accountUser != null) {
			return "Account Number Already exists. Please try another account number or login !!";
		}
		return "error while creating account";
		}catch(Exception e) {
			userRepo.save(user);
			 return "Account Created Successfully";
		}
		 

	}
//****************************************************End of Create Account function*****************************************************************************************

//****************************************************Function for updating account*****************************************************************************************
	
	public AccountUser updateAccount(AccountUser user) {
		try {
			Optional<AccountUser> optionalAccountUser = userRepo.findById(user.getAccountNo());
			AccountUser accountUser = optionalAccountUser.get();
			if (accountUser != null) {
				//user.setBalance(accountUser.getBalance());
				accountUser.setPin(user.getPin());
				return userRepo.save(accountUser);
			} else {
				throw new UserAccountWithNumberNotFoundException();
			}
		} catch (Exception e) {
				System.out.println(e.getClass());
			return null;
		}

	}
//****************************************************End of Update account function*****************************************************************************************
	

//****************************************************Function for Withdraw money*****************************************************************************************
	
	public String withdraw(Double money, AccountUser user) {
		String result ="error";
		try {
			Optional<AccountUser> optionalAccountUser = userRepo.findById(user.getAccountNo());
			AccountUser accountUser = optionalAccountUser.get();
			if (accountUser != null) {
				if(accountUser.getPin().equals(user.getPin())) {
				if (accountUser.getBalance() - money >= 0) {
					accountUser.setBalance(accountUser.getBalance() - money);
					Date time = new Date();
					AccountTransaction newTransaction = new AccountTransaction(accountUser.getAccountNo() + "" + time,
							accountUser.getAccountNo(), money, time, "Self withdraw");
					final AccountTransaction trans = transactionRepo.save(newTransaction);
					if (trans != null) {
						accountUser.setBalance(accountUser.getBalance() + money);
						result = "Money withdraw successfully!!";
					} else {
						result = "Money withdraw unsuccessfull !!";
						
					}
					
				} else {
					throw new InsufficientBalanceException("Low balance");
				}
				}else {
					result = "Incorrect pin";
				}
			} else {
				throw new UserAccountWithNumberNotFoundException();
			}
			return result;
		} catch (InsufficientBalanceException e) {
			// TODO: handle exception
			result = e.getMessage();
			return result;
		}
		catch (Exception e) {
			// TODO: handle exception
			result = "Account does not exist";
			return result;
		}finally {
			return result;
		}

	}
//****************************************************End of Withdraw function*****************************************************************************************
	

	
//****************************************************Function for depositing money*****************************************************************************************
		
	@SuppressWarnings("finally")
	public String deposit(float money, AccountUser user) {
		String result = null;

		try {
			Optional<AccountUser> optionalAccountUser = userRepo.findById(user.getAccountNo());
			AccountUser accountUser = optionalAccountUser.get();
			if (accountUser != null) {
				if(accountUser.getPin().equals(user.getPin())) {
				accountUser.setBalance(accountUser.getBalance() + money);
				Date time = new Date();
				AccountTransaction newTransaction = new AccountTransaction(accountUser.getAccountNo() + "" + time,
						accountUser.getAccountNo(), money, time, "Self deposit");
				final AccountTransaction trans = transactionRepo.save(newTransaction);
				if (trans == null) {
					accountUser.setBalance(accountUser.getBalance() - money);
					result = "Transaction rolled back";
				} else {
					result = "Amount deposited successfully";
				}
				}else{
					result = "Incorrect pin";
				}
					
			} else {

				throw new UserAccountWithNumberNotFoundException();
			}
		} 
		catch (Exception e) {
			// TODO: handle exception
			result = "Account does not exist";
			return result;
		}finally {
			return result;
		}
	}
//****************************************************End of deposit function*****************************************************************************************
		
	
//****************************************************Function for get account by id*****************************************************************************************
	
	public AccountUser getAccountById(String number) {
		try {
			Optional<AccountUser> optionalAccountUser = userRepo.findById(number);
			AccountUser user = optionalAccountUser.get();
			if (user != null) {
				return user;
			} else {
				throw new UserAccountWithNumberNotFoundException();
			}
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
	}
//****************************************************End of get Account by id function*****************************************************************************************
	
	
//****************************************************Function for log in*****************************************************************************************
	
	@SuppressWarnings("finally")
	public String Login(AccountUser user1) {
		String result = null;
		try {
			Optional<AccountUser> optionalAccountUser = userRepo.findById(user1.getAccountNo());
			AccountUser user = optionalAccountUser.get();
			if (user == null) {
				throw new UserAccountWithNumberNotFoundException();
			} else if (user.getPin().equals(user1.getPin())) {
				result = "Login successfull !!";
			} else {
				result = "Pin does not match";
			}
		} catch (Exception e) {
			// TODO: handle exception
			result = "Account Number is invalid !!";
		} finally {
			return result;
		}
	}
//****************************************************End of login function*****************************************************************************************
	
	
//****************************************************Function for getting balance*****************************************************************************************
	
	@SuppressWarnings("finally")
	public String getBalance(String number) {
		String result = null;
		try {
			Optional<AccountUser> optionalAccountUser = userRepo.findById(number);
			AccountUser user = optionalAccountUser.get();
			if (user == null) {
				throw new UserAccountWithNumberNotFoundException();
			} else {
				result = "balance is "+user.getBalance();
			}

		} catch (Exception e) {
			// TODO: handle exception
			result = "Account Does Not Exists";
		} finally {
			return result;
		}

	}
//****************************************************End of get balance function*****************************************************************************************
	
	
//****************************************************Function for printing Transactions*****************************************************************************************
		
	public List<AccountTransaction> printTransaction(String number) {
		try {
			Optional<AccountUser> optionalAccountUser = userRepo.findById(number);
			AccountUser user = optionalAccountUser.get();
			if (user != null) {
				List<AccountTransaction> transactions = transactionRepo.findByAccountNo(number);
				return (transactions);
			} else {
				throw new UserAccountWithNumberNotFoundException();
			}
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		
	}
//****************************************************End of Print Transaction function*****************************************************************************************

//****************************************************Function for FundTransfer*****************************************************************************************
	@SuppressWarnings({ "finally", "null" })
	public String fundTransfer(float amount, String accountNumber, AccountUser user) {
		String result =null;
		
			AccountUser user1 = getAccountById(user.getAccountNo());
			
			AccountUser user2 = getAccountById(accountNumber);
			
			try {
			 if(user1 ==null) {
				
				 throw new UserAccountWithNumberNotFoundException();
			 }
			 else if(user2 ==null) {
				
				 throw new UserAccountWithNumberNotFoundException();
			 }
			 else  if (user1.getBalance() - amount < 0) {
				throw new InsufficientBalanceException("Low balance");
			} else {
				if(user1.getPin().equals(user.getPin())) {

				Date time = new Date();
				AccountTransaction Transaction1 = new AccountTransaction(user1.getAccountNo() + "" + time,
						user1.getAccountNo(), amount, time, "fundTransfer to " + accountNumber);
				final AccountTransaction trans1 = transactionRepo.save(Transaction1);
				AccountTransaction Transaction2 = new AccountTransaction(user2.getAccountNo() + "" + time,
						user2.getAccountNo(), amount, time, "fundTransfer" + accountNumber);
				final AccountTransaction trans2 = transactionRepo.save(Transaction2);
				if (trans1 != null && trans2 != null) {
					result = "Fund transfered successfully !!";
					user1.setBalance(user1.getBalance() - amount);
					user2.setBalance(user2.getBalance() + amount);
					AccountUser tempuser1 = user1;
					AccountUser tempuser2 = user2;
					userRepo.delete(tempuser1);
					userRepo.delete(tempuser2);
					userRepo.save(user1);
					userRepo.save(user2);
				} else if (trans1 == null) {
					if (trans2 == null) {
						result = "Transfer unsuccessfull!!";
					} else {
						transactionRepo.delete(trans2);
						result = "Transfer unsuccessfull!!";
					}
				} else if (trans2 == null && trans1 != null) {
					transactionRepo.delete(trans1);
					result = "Transfer unsuccessfull!!";

				}
				}
			}
			
		}
		catch (InsufficientBalanceException e) {
			System.out.println("m1");
			result = e.getMessage();
		}
		catch (Exception e) {
			
				 result = "Account does not exist";
			
		}finally {
			return (result);
		}
	}
//****************************************************End of Fund Transfer function*****************************************************************************************
	
}
