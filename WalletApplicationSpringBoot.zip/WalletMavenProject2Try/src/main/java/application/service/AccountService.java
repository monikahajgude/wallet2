package application.service;

import java.util.List;

import application.model.AccountTransaction;
import application.model.AccountUser;

public interface AccountService {
	public List<AccountUser> getAllAccount();

	public String createAccount(AccountUser user);

	public AccountUser updateAccount(AccountUser user);

	public String withdraw(Double money, AccountUser user);

	public String deposit(float money, AccountUser user);

	public AccountUser getAccountById(String number);

	public String Login(AccountUser user1);

	public String getBalance(String number);

	public List<AccountTransaction> printTransaction(String number);

	public String fundTransfer(float amount, String accountNumber, AccountUser user);
}
