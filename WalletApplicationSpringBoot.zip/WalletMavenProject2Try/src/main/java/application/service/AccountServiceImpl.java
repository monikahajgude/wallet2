package application.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import application.Dao.DaoImpl;
import application.model.AccountTransaction;
import application.model.AccountUser;

@Service
public class AccountServiceImpl implements AccountService{
	
	@Autowired
	DaoImpl accountDao;
	
	public AccountServiceImpl() {
		accountDao=new DaoImpl();
	}
	
	@Override
	public List<AccountUser> getAllAccount() {
		// TODO Auto-generated method stub
		return accountDao.getAllAccount();
	}

	@Override
	public String createAccount(AccountUser user) {
		// TODO Auto-generated method stub
		return accountDao.createAccount(user);
	}

	@Override
	public AccountUser updateAccount(AccountUser user) {
		// TODO Auto-generated method stub
		return accountDao.updateAccount(user);
	}

	@Override
	public String withdraw(Double money, AccountUser user) {
		// TODO Auto-generated method stub
		return accountDao.withdraw(money, user);
	}

	@Override
	public String deposit(float money, AccountUser user) {
		// TODO Auto-generated method stub
		return accountDao.deposit(money, user);
	}

	@Override
	public AccountUser getAccountById(String number) {
		// TODO Auto-generated method stub
		return accountDao.getAccountById(number);
	}

	@Override
	public String Login(AccountUser user1) {
		// TODO Auto-generated method stub
		return accountDao.Login(user1);
	}

	@Override
	public String getBalance(String number) {
		// TODO Auto-generated method stub
		return accountDao.getBalance(number);
	}

	@Override
	public List<AccountTransaction> printTransaction(String number) {
		// TODO Auto-generated method stub
		return accountDao.printTransaction(number);
	}

	@Override
	public String fundTransfer(float amount, String accountNumber, AccountUser user) {
		// TODO Auto-generated method stub
		return accountDao.fundTransfer(amount, accountNumber, user);
	}

}
