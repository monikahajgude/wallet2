package application.exceptionHandling;


/*user define exception if account not exist*/
public class UserAccountWithNumberNotFoundException extends Exception{

	private static final long serialVersionUID = 1L;

	public UserAccountWithNumberNotFoundException(){
    	super();
   }
	public UserAccountWithNumberNotFoundException(String message){
    	super(message);
   }
	
	public String getMessage() {
		return super.getMessage();
	}
}
