package application.exceptionHandling;


/*user define exception for insufficient balance*/
public class InsufficientBalanceException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public InsufficientBalanceException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	public String getMessage(){
		String msg = super.getMessage();
			return msg;
	}
}
