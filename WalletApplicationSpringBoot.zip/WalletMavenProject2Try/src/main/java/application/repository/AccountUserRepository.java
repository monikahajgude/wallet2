package application.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import application.model.AccountUser;
/* user reposatory class*/
public interface AccountUserRepository extends JpaRepository<AccountUser,String>{

}
