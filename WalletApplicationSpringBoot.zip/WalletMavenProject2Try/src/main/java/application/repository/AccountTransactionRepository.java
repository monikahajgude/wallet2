 package application.repository;
 
 import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
 
 import application.model.AccountTransaction;
  /*transaction repository class*/
  public interface AccountTransactionRepository extends
  JpaRepository<AccountTransaction,String>{
  public List<AccountTransaction> findByAccountNo(String accountNo);
  }
 