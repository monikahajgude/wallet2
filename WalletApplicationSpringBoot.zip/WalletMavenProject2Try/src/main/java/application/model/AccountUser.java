package application.model;




import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/*entity class for account users*/

@Entity
@Table(name="AccountUserDetails")
public class AccountUser {
	
	@Id
	private String accountNo;
	private double balance;
	private String firstName;
	private String lastName;
	private String pin;
	public AccountUser() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AccountUser(String accountNo, double balance, String firstName, String lastName, String pin) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
		this.firstName = firstName;
		this.lastName = lastName;
		this.pin = pin;
	}
	@Override
	public String toString() {
		return "AccountUser [accountNo=" + accountNo + ", balance=" + balance + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", pin=" + pin + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountNo == null) ? 0 : accountNo.hashCode());
		long temp;
		temp = Double.doubleToLongBits(balance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((pin == null) ? 0 : pin.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountUser other = (AccountUser) obj;
		if (accountNo == null) {
			if (other.accountNo != null)
				return false;
		} else if (!accountNo.equals(other.accountNo))
			return false;
		if (Double.doubleToLongBits(balance) != Double.doubleToLongBits(other.balance))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (pin == null) {
			if (other.pin != null)
				return false;
		} else if (!pin.equals(other.pin))
			return false;
		return true;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	
	
}
