import { Component, OnInit } from '@angular/core';
import { HttpClientService, Account,AccountUser } from '../Service/http-client.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  /*user = sessionStorage.getItem('username')
  user1:AccountUser;
  accountData: Account = new Account("","",this.user1,null);
  transactions;*/
  constructor(
    private router: Router,
    private loginservice: AuthenticationService,
    private httpClientService: HttpClientService,
    
  ) { }
  ngOnInit() {
   // this.httpClientService.getUser(this.user).subscribe(data => this.accountData = data);
  }
  
  
}
