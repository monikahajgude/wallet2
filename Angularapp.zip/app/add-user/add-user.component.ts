import { Component, OnInit } from '@angular/core';
import { HttpClientService, Account,  AccountUser } from '../Service/http-client.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
 
  user:AccountUser;
  account: Account = new Account("","",this.user,null);
  
  constructor(
    private httpClientService: HttpClientService,
    private router : Router
  ) { }

  ngOnInit() {
  }
  createUser(): void {
    console.log(this.account);
    this.httpClientService.createUser(this.account)
        .subscribe( data => {
          if(data){
            alert("Account registered successfully.");
            this.router.navigate(['login']);
          }
          else{
            alert("Account Number not available in bank. Please enter correct account number");
            this.router.navigate(['adduser']);
          }
        });

  };
}
