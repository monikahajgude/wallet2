import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { HttpClientService,Account,AccountUser } from '../Service/http-client.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  
  accountNum:string;
  pin:string;
  userId:string;
  user:AccountUser = new AccountUser(this.userId,"","",this.pin);
  account: Account = new Account(this.accountNum,"",this.user,null);
  invalidLogin = false
  constructor(
    private router: Router,
    private loginservice: AuthenticationService,
    private httpClientService: HttpClientService,
    ) { }

  ngOnInit() {
  }

  checkLogin() {
    
    this.loginservice.authenticate(this.accountNum,this.account).subscribe(
      x=>{
        console.log(x);
        if(x!=null)
        {
          sessionStorage.setItem('username', x.accNo);
          this.invalidLogin = false;
          this.router.navigate(['home']);
        }
        else{
        alert('Invalid credentials!!! Please enter correct details');
        }
      }
    );
  }
}
