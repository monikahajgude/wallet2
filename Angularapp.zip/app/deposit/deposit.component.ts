import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { HttpClientService, AccountUser,Account,Transaction } from '../Service/http-client.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  user:AccountUser;
  transactions:Transaction;
  account: Account = new Account("","",this.user,this.transactions);
  currentUser;
  amount;
  constructor(
    private router: Router,
    private loginservice: AuthenticationService,
    private httpClientService: HttpClientService,
  ) { }

  ngOnInit() {
  }
  deposit(){
    this.currentUser = sessionStorage.getItem('username');
    if(this.account.accNo===this.currentUser){
      this.httpClientService.deposit(this.account,this.amount).subscribe(
      x=>{
        if(x)
        {
          alert("Amount deposited successfully");
          this.router.navigate(['home']);
        }
        else{
          alert("Sorry amount could not be deposited");
          this.router.navigate(['deposit']);
        }
      });
    }
    else{
      alert("Please enter correct account number");
    }
  }
}
