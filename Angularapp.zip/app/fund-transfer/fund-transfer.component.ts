import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { HttpClientService, AccountUser,Account,Transaction } from '../Service/http-client.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {
  user:AccountUser;
  
  account: Account = new Account("","",this.user,null);
  currentUser;
  amount;
  accountNumber2
  constructor(
    private router: Router,
    private loginservice: AuthenticationService,
    private httpClientService: HttpClientService,
  ) { }

  ngOnInit() {
  }
  fundTransfer(){
    this.currentUser = sessionStorage.getItem('username');
    if(this.account.accNo===this.currentUser){
      this.httpClientService.fundTransfer(this.account,this.amount,this.accountNumber2).subscribe(
      x=>{
        if(x)
        {
          alert("fund transfered successfully");
          this.router.navigate(['home']);
        }
        else{
          alert("Sorry amount could not be transfered");
          this.router.navigate(['fundTransfer']);
        }
      });
    }
    else{
      alert("Please enter correct account number");
    }
  }
}
