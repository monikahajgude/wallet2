import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClientService,  Account } from '../Service/http-client.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(
    private router: Router,
    private loginservice: AuthenticationService,
    private httpClientService: HttpClientService,
    private httpClient:HttpClient,
    
  ) { }
  
  authenticate(accountNum,account): Observable<Account>{
    return this.httpClient.post<Account>(`http://localhost:8080/wallet/doLogin/${accountNum}`, account);
  }
  
  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    console.log(user);
    console.log(!(user === null))
    return !(user === null)
  }
  logOut() {
    sessionStorage.removeItem('username')
  }
}