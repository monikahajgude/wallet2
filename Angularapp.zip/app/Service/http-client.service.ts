import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RequestOptions } from '@angular/http';


export class Account{
  constructor(
    public accNo:string,
    public balance:string,
    public user:AccountUser,
    public transactions:Transaction,
  ) {}
}
export class AccountUser{
  constructor(
    public  uuid:string,
    public firstName:string,
    public lastName:string,
     public pin:string
  ){}
}
export class Transaction{
  constructor(
    public transactionId:string,
    public amount:string,
    public timeStamp:string,
    public description:string
  ){}
}

@Injectable({
  providedIn: 'root'
})
export class HttpClientService {

  constructor(
    private httpClient:HttpClient
  ) { 
     }

  public createUser(account):Observable<any>{
    return this.httpClient.post<any>("http://localhost:8080/wallet"+"/create", account);
  }
  getUser(acc_no):Observable<Account>{
    return this.httpClient.get<Account>(`http://localhost:8080/wallet/getUser/${acc_no}`);
}

  deposit(account,amount):Observable<any>{
    const baseURL='http://localhost:8080/wallet';
    console.log(account);
    console.log(amount);
    return this.httpClient.post<any>(`${baseURL}/deposit/${amount}`, account);
  }
  withdraw(account,amount):Observable<any>{
    console.log(account);
    console.log(amount);
    return this.httpClient.post<any>(`http://localhost:8080/wallet/withdraw/${amount}`, account);
  }
  fundTransfer(account,amount,accountNumber1):Observable<any>{
    console.log(account);
    console.log(amount);
    console.log(accountNumber1);
    return this.httpClient.post<any>(`http://localhost:8080/wallet/fundtransfer/${amount}/${accountNumber1}`, account);
  }
}