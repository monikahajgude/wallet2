import { Component, OnInit } from '@angular/core';
import { Account,AccountUser, HttpClientService } from '../Service/http-client.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  user:AccountUser;
  account: Account = new Account("","",this.user,null);
  amount;
  currentUser;
  constructor(
    private router: Router,
    private loginservice: AuthenticationService,
    private httpClientService: HttpClientService,
  ) { }

  ngOnInit() {
  }

  withdraw(){
    this.currentUser = sessionStorage.getItem('username');
    if(this.account.accNo===this.currentUser){
      
        this.httpClientService.withdraw(this.account,this.amount).subscribe(
        x=>{
          if(x)
          {
            alert("Amount withdrawn successfully");
            this.router.navigate(['home']);
          }
          else{
            alert("Sorry!!! Insufficient balance.");
            this.router.navigate(['withdraw']);
          }
        });
      }
      else{
        alert('Please enter correct account number');
      }
    }
}