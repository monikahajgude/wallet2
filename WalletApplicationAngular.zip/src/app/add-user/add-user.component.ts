import { Component, OnInit } from '@angular/core';
import { HttpClientService, User,ResultMessage } from '../Service/http-client.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  user: User = new User("","","","","");
  title = "Create Account";
  result:ResultMessage=new ResultMessage("");
  confirmPin;
  constructor(
    private httpClientService: HttpClientService,
    private router : Router
  ) { }

  ngOnInit() {
  }
  createUser(): void {
    console.log(this.user);
    if(this.confirmPin == this.user.pin){
    this.httpClientService.createUser(this.user)
        .subscribe( data => {
          this.result=data;
          if(this.result.message == "Account Created Successfully"){
            alert(this.result.message);
            this.router.navigate(['login']);
          }
          else{
            alert(this.result.message);
            this.router.navigate(['adduser']);
          }
        });
      }else{
        alert("Pin and Comfirm pin does not match.");
        this.router.navigate(['adduser']);
      }
  };
}
