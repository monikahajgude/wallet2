import { Component, OnInit } from '@angular/core';
import { User, HttpClientService ,ResultMessage } from '../Service/http-client.service';
import { Router,ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  user: User = new User("","","","","");
  amount=0;
  currentUser;
  userData: User = new User("","","","","");
  title:"Withdraw";
  result:ResultMessage=new ResultMessage("");
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    
    private httpClientService: HttpClientService,
  ) { }

  ngOnInit() {
    this.httpClientService.getUser(sessionStorage.getItem('username')).subscribe(data => this.userData = data);
  }

  withdraw(){
    this.currentUser = sessionStorage.getItem('username');
    if(this.user.accountNo===this.currentUser){
      if(this.amount>0){
        this.httpClientService.withdraw(this.user,this.amount).subscribe(
          x=>{
            this.result = x;
            if(this.result.message =="Money withdraw successfully!!")
            {
              alert(this.result.message);
              this.router.navigate(['home']);
            }
            else{
              alert(this.result.message);
              this.router.navigate(['withdraw']);
            }
          });
        }
        else{
          alert("Amount should be more than zero.");
        }
      }else{
        alert("Please enter correct account number .");
      }
    }
}