﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { AddUserComponent } from './add-user/add-user.component';
import { HomeComponent } from './home/home.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { PrintTransactionComponent } from './print-transction/print-transaction.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';

@NgModule({
    imports: [
        BrowserModule,
        AppRoutingModule,
        HttpClientModule,
        FormsModule,
        ReactiveFormsModule
       
    ],
    declarations: [
        AppComponent,
        HeaderComponent,
        LoginComponent ,
        LogoutComponent ,
        AddUserComponent ,
        HomeComponent ,
        DepositComponent ,
        WithdrawComponent ,
        FundTransferComponent,
        PrintTransactionComponent,
        EditProfileComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }