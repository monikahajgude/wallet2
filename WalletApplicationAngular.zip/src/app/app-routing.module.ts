import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { AddUserComponent } from './add-user/add-user.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent} from './withdraw/withdraw.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { PrintTransactionComponent } from './print-transction/print-transaction.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { AuthenticationService} from './Service/authentication.service';
const routes: Routes = [
    { path: 'printTransaction', component: PrintTransactionComponent,canActivate:[AuthenticationService]},
    { path: 'login', component: LoginComponent},
    { path: 'logout', component: LogoutComponent,canActivate:[AuthenticationService]},
    { path: 'adduser', component: AddUserComponent},
    { path: "home", component: HomeComponent,canActivate:[AuthenticationService]},
    { path: 'home1', component: HeaderComponent},
    { path: 'deposit', component: DepositComponent,canActivate:[AuthenticationService]},
    { path: 'withdraw', component: WithdrawComponent,canActivate:[AuthenticationService]},
    { path: 'fundtransfer', component: FundTransferComponent,canActivate:[AuthenticationService]},
    { path: 'editProfile', component:EditProfileComponent,canActivate:[AuthenticationService]}
  ];
  @NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }