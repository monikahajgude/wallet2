import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { HttpClientService, User,ResultMessage } from '../Service/http-client.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  user: User = new User("","","","","");
  userData: User = new User("","","","","");
  amount;
  result:ResultMessage=new ResultMessage("");
  currentUser;
  title:"deposit";
  constructor(
    private router: Router,
    private httpClientService: HttpClientService,
  ) { }

  ngOnInit() {
    this.httpClientService.getUser(sessionStorage.getItem('username')).subscribe(data => this.userData = data);
  }
  deposit(){
    this.currentUser = sessionStorage.getItem('username');
    if(this.user.accountNo===this.currentUser){
      if(this.amount>0){
      this.httpClientService.deposit(this.user,this.amount).subscribe(
      x=>{
        this.result = x;
        if(this.result.message =="Amount deposited successfully")
        {
          alert(this.result.message);
          this.router.navigate(['home']);
        }
        else{
          alert(this.result.message);
          this.router.navigate(['deposit']);
        }
      });
    }
    else{
      alert("Amount should be more than zero.");
    }
  }
    else{
      alert("Please enter correct account number");
    }
  }
}
