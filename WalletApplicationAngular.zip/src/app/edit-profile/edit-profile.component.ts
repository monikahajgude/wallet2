import { Component, OnInit } from '@angular/core';
import { HttpClientService, User } from '../Service/http-client.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-user',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  user: User = new User("","","","","");
  userData: User = new User("","","","","");
  accountNo:string;
  title = "Create Account";
  currentpin;
  confirmChangedPin;
  constructor(
    private httpClientService: HttpClientService,
    private router : Router
  ) { }

  ngOnInit() {
    this.httpClientService.getUser(sessionStorage.getItem('username')).subscribe(data => this.userData = data);
    
  }
  editUser(): void {
    this.user.accountNo = this.userData.accountNo;
   if(this.userData.pin == this.currentpin){
    if(this.user.pin == this.confirmChangedPin){
    this.httpClientService.editUser(this.user)
        .subscribe( data => {
          if(data){
            alert("Pin changed successfully.");
            this.router.navigate(['login']);
          }
          else{
            alert("Pin change unsuccessfull");
            this.router.navigate(['editProfile']);
          }
        });
      }else{
        alert("changed pin and comfirm pin does not match . ");
        this.router.navigate(['editProfile']);
      }
   }else{
    alert("Current pin is incorrect.");
    this.router.navigate(['editProfile']);
   }

  };

}
