﻿import { Component } from '@angular/core';
import { HttpClientService, User } from './Service/http-client.service';
import { Router } from '@angular/router';
import { OnInit } from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html'
})

export class AppComponent {
    isLogin:boolean;
    constructor(
        private router: Router,
         private httpClientService: HttpClientService,
        
      ) { }
      
      setNav(){
        if(this.httpClientService.isUserLoggedIn()){
            return true;

        }
        else{
            return false;
        }
      }
 }