import { Component, OnInit } from '@angular/core';
import { User, HttpClientService,ResultMessage } from '../Service/http-client.service';
import { Router,ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {
  user: User = new User("","","","","");
  userData: User = new User("","","","","");
  amount;
  accountNumber1;
  currentUser;
  title:"deposit";
  result:ResultMessage=new ResultMessage("");
  constructor(
    private router: Router,
   
    private httpClientService: HttpClientService,
  ) { }

  ngOnInit() {
    this.httpClientService.getUser(sessionStorage.getItem('username')).subscribe(data => this.userData = data);
  }
  fundTransfer(){
    this.currentUser = sessionStorage.getItem('username');
  
      if(this.amount>0){
      this.httpClientService.fundTransfer(this.user,this.amount,this.accountNumber1).subscribe(
      
      x=>{
        this.result = x;
        if(this.result.message =="Fund transfered successfully !!")
        {
          alert(this.result.message);
          this.router.navigate(['home']);
        }
        else if(this.result.message=="Account does not exist"){
          alert(this.result.message+"for this number:"+this.accountNumber1);
          this.router.navigate(['fundtransfer']);
        }
        else{
          alert(this.result.message);
          this.router.navigate(['fundtransfer']);
        }
      });
    }
    else{
      alert("Amount should be more than zero.");
    }
      
      }
}