import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { HttpClientService, User,ResultMessage } from '../Service/http-client.service';
import { FormBuilder, Validators, AbstractControl } from "@angular/forms";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  user: User = new User("","","","","");
 result:ResultMessage=new ResultMessage("");
  constructor(
    private httpClientService: HttpClientService,
    private router : Router
  ) { }

  ngOnInit() {
  }
 onSubmit(): void {
    console.log(this.user);
    this.httpClientService.logUser(this.user)
        .subscribe( data => {
          
            this.result=data;
            if(this.result.message == "Login successfull !!"){
            sessionStorage.setItem('username', this.user.accountNo);
            alert(this.result.message);
            this.router.navigate(['home']);
          }
          else{
            alert(this.result.message);
            this.router.navigate(['login']);
          }
        });

  };
}

