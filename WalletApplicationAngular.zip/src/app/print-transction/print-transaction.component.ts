import { Component, OnInit } from '@angular/core';
import { HttpClientService, User } from '../Service/http-client.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-home',
  templateUrl: './print-transaction.component.html',
  styleUrls: ['./print-transaction.component.css']
})
export class PrintTransactionComponent implements OnInit {
  user1 = sessionStorage.getItem('username')
  user: User = new User("","","","","");
  transactions:string[];
  accountNum;
  constructor(
    private router: Router,
     private httpClientService: HttpClientService,
    
  ) { }
  ngOnInit() {
    this.httpClientService.getUser(this.user1).subscribe(data => this.user = data);
    this.httpClientService.printTransaction(this.user1).subscribe(data => this.transactions = data);
    
  }
 
  
}
