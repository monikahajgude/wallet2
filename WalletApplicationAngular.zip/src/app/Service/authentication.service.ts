 import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { HttpClientService, User } from '../Service/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService implements CanActivate {

  constructor(private router: Router,
    private httpClientService: HttpClientService,) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (this.httpClientService.isUserLoggedIn())
      return true;

    this.router.navigate(['login']);
    return false;

  }

}