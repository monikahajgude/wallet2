import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';



  export class User{
    constructor(
      public  accountNo:string,
      public  balance:string,
      public  firstName:string,
      public  lastName:string,
      public  pin:string,
    ) {}
}
export class Transaction{
  constructor(
    public transactionId:string,
    public accountNo:string,
    public amount:string,
    public  timeStamp:string,
    public  description:string,
  ) {}
}
export class ResultMessage{
  constructor(
    public message:string
  ){}
}
@Injectable({
  providedIn: 'root'
})
 export class HttpClientService {          

  constructor(
    private httpClient:HttpClient
  ) { 
     }


     
   public  logUser(user): Observable<ResultMessage>{
      return this.httpClient.post<ResultMessage>(`http://localhost:8080/wallet/doLogin`, user);
    }
  public createUser(user):Observable<ResultMessage>{
    return this.httpClient.post<ResultMessage>("http://localhost:8080/wallet"+"/createAccount", user);
  }
  public editUser(user):Observable<any>{
    return this.httpClient.post<any>("http://localhost:8080/wallet/updateAccount",user);
  }
  getUser(acc_no):Observable<User>{
    return this.httpClient.get<User>(`http://localhost:8080/wallet/getUser/${acc_no}`);
}
printTransaction(acc_no):Observable<any>{
  return this.httpClient.get<Transaction[]>(`http://localhost:8080/wallet/printTransaction/${acc_no}`);
}

deposit(user,amount):Observable<ResultMessage>{
    const baseURL='http://localhost:8080/wallet';
    return this.httpClient.post<ResultMessage>(`${baseURL}/deposit/${amount}`, user);
}

withdraw(user,amount):Observable<ResultMessage>{
   return this.httpClient.post<ResultMessage>(`http://localhost:8080/wallet/withdraw/${amount}`, user);
}
fundTransfer(user,amount,accountNumber1):Observable<ResultMessage>{
    return this.httpClient.post<ResultMessage>(`http://localhost:8080/wallet/fundtransfer/${amount}/${accountNumber1}`, user);
}
  
  public logOut() {
    sessionStorage.removeItem('username')
  }
  public isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    console.log(user);
    console.log(!(user === null))
    return !(user === null)
  }
}