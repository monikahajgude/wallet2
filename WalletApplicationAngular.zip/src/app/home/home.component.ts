import { Component, OnInit } from '@angular/core';
import { HttpClientService, User } from '../Service/http-client.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 
user: User = new User("","","","","");
 accountNumber = sessionStorage.getItem('username')
  title = "Create Account";
  constructor(
    private httpClientService: HttpClientService,
    private router : Router
  ) { }

  ngOnInit() {
    
    this.httpClientService.getUser(this.accountNumber).subscribe(data => this.user = data);
  }
  
}

